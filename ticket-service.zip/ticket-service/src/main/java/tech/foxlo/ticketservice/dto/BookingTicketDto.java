package tech.foxlo.ticketservice.dto;

import java.util.UUID;

public record BookingTicketDto(UUID bookingId) {
}
