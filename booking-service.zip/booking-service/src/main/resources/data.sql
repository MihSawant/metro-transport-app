INSERT INTO stations(code, cost, name) VALUES ('gc', 10, 'ghatkopar');
INSERT INTO stations(code, cost, name) VALUES ('jn', 10, 'jagruti-nagar');
INSERT INTO stations(code, cost, name) VALUES ('al', 10, 'asalpha');
INSERT INTO stations(code, cost, name) VALUES ('sk', 10, 'saki-naka');
INSERT INTO stations(code, cost, name) VALUES ('mk', 10, 'marol-naka');
INSERT INTO stations(code, cost, name) VALUES ('ard', 10, 'airport-road');
INSERT INTO stations(code, cost, name) VALUES ('ck', 10, 'chakala-jb-nagar');
INSERT INTO stations(code, cost, name) VALUES ('weh', 10, 'western-express-highway');
INSERT INTO stations(code, cost, name) VALUES ('and', 10, 'andheri');
INSERT INTO stations(code, cost, name) VALUES ('an', 10, 'azad-nagar');
INSERT INTO stations(code, cost, name) VALUES ('dn', 10, 'dn-nagar');
INSERT INTO stations(code, cost, name) VALUES ('vr', 10, 'versova');

